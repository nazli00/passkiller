﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using Newtonsoft.Json;
using System.IO;
using System.Xml.Linq;

namespace WpfApp11
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>
    public partial class MainWindow : Window
    {
        private const string dataFilePath = "passwords.xml";
        private XDocument passwordsDocument;

        public MainWindow()
        {
            InitializeComponent();
            InitializeData();
        }

        private void InitializeData()
        {
            if (File.Exists(dataFilePath))
            {
                passwordsDocument = XDocument.Load(dataFilePath);
            }
            else
            {
                passwordsDocument = new XDocument(new XElement("Passwords"));
            }
        }

        private void CloseButton_Click(object sender, RoutedEventArgs e)
        {
            Close();
        }

        private void MinimizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = WindowState.Minimized;
        }

        private void MaximizeButton_Click(object sender, RoutedEventArgs e)
        {
            WindowState = (WindowState == WindowState.Maximized) ? WindowState.Normal : WindowState.Maximized;
        }

        private void SavePasswordButton_Click(object sender, RoutedEventArgs e)
        {
            string website = WebsiteTextBox.Text;
            string username = UsernameTextBox.Text;
            string password = PasswordTextBox.Password;

            XElement passwordElement = new XElement("Password",
                new XElement("Website", website),
                new XElement("Username", username),
                new XElement("Password", password)
            );

            passwordsDocument.Root!.Add(passwordElement);
            passwordsDocument.Save(dataFilePath);
            WebsiteTextBox.Clear();
            UsernameTextBox.Clear();
            PasswordTextBox.Clear();
        }

        private void RetrievePasswordsButton_Click(object sender, RoutedEventArgs e)
        {
            PasswordList.Items.Clear();

            IEnumerable<XElement> passwordElements = passwordsDocument.Root!.Elements("Password");

            foreach (XElement passwordElement in passwordElements)
            {
                string website = passwordElement.Element("Website")!.Value;
                string username = passwordElement.Element("Username")!.Value;
                string password = passwordElement.Element("Password")!.Value;

                PasswordList.Items.Add($"Website: {website}, Username: {username}, Password: {password}");
            }
        }
    }
}
